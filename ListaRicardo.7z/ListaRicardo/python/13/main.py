import math

class Matematica:
    @staticmethod
    def fatorial(n):
        return math.factorial(n)

# Exemplo de uso
print(Matematica.fatorial(5))  # 120
